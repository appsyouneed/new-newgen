import express from "express";
import path from "path";
import { spawn, ChildProcess, execSync } from "child_process";
import fs from "fs";
import { createServer as createViteServer } from "vite";

interface LogEntry {
  id: string;
  timestamp: string;
  type: "stdout" | "stderr" | "system" | "command";
  text: string;
}

let activeProcess: ChildProcess | null = null;
let activeCommand: string | null = null;
let activeProcessId: string | null = null;
const logBuffer: LogEntry[] = [];
const MAX_LOGS = 3000;

// SSE connected clients
const sseClients = new Set<express.Response>();

function broadcast(event: string, data: any) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch {
      sseClients.delete(client);
    }
  }
}

function appendLog(type: LogEntry["type"], text: string) {
  const entry: LogEntry = {
    id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString().split("T")[1].replace("Z", ""),
    type,
    text,
  };
  logBuffer.push(entry);
  if (logBuffer.length > MAX_LOGS) {
    logBuffer.shift();
  }
  broadcast("log", entry);
  return entry;
}

function clearDpkgLocks() {
  try {
    execSync("fuser -k -9 /var/lib/dpkg/lock-frontend 2>/dev/null || true");
    execSync('pkill -9 -f "/usr/bin/dpkg" 2>/dev/null || true');
    execSync('pkill -9 -f "apt-get" 2>/dev/null || true');
    execSync("rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock /var/cache/apt/archives/lock 2>/dev/null || true");
    execSync("DEBIAN_FRONTEND=noninteractive dpkg --configure -a --force-confdef --force-confold 2>/dev/null || true");
  } catch (err) {}
}

function detectAndHandlePrompt(text: string, proc: ChildProcess) {
  // Check for debconf / dpkg interactive prompts like:
  // *** mime.types (Y/I/N/O/D/Z) [default=N] ?
  // What would you like to do about it ?
  // [default=N]
  // [Y/n] or [y/N]
  const defaultMatch = text.match(/\[default=([A-Za-z0-9]+)\]/i);
  if (defaultMatch && defaultMatch[1]) {
    const answer = defaultMatch[1];
    setTimeout(() => {
      try {
        proc.stdin?.write(`${answer}\n`);
        appendLog("system", `[Auto-Prompt-Handler: Answered '${answer}' (default) to interactive question]`);
      } catch (err) {}
    }, 150);
    return;
  }

  if (text.includes("(Y/I/N/O/D/Z)")) {
    setTimeout(() => {
      try {
        proc.stdin?.write("N\n");
        appendLog("system", `[Auto-Prompt-Handler: Answered 'N' (keep existing) to (Y/I/N/O/D/Z) prompt]`);
      } catch (err) {}
    }, 150);
    return;
  }

  if (/Do you want to continue\?\s*\[Y\/n\]/i.test(text) || /\[Y\/n\]/i.test(text)) {
    setTimeout(() => {
      try {
        proc.stdin?.write("Y\n");
        appendLog("system", `[Auto-Prompt-Handler: Answered 'Y' to continue prompt]`);
      } catch (err) {}
    }, 150);
    return;
  }

  if (/Press\s*(\[?ENTER\]?|any key)\s*to continue/i.test(text)) {
    setTimeout(() => {
      try {
        proc.stdin?.write("\n");
        appendLog("system", `[Auto-Prompt-Handler: Sent Enter to continue]`);
      } catch (err) {}
    }, 150);
    return;
  }
}

function runCommand(command: string, cwd: string = "."): { ok: boolean; message?: string } {
  if (activeProcess) {
    return { ok: false, message: "A process is already running. Terminate it first." };
  }

  const resolvedCwd = path.resolve(process.cwd(), cwd);
  const pid = `${Date.now()}`;
  activeProcessId = pid;
  activeCommand = command;

  appendLog("command", `$ (${cwd}) ${command}`);

  try {
    const proc = spawn("bash", ["-c", command], {
      cwd: resolvedCwd,
      env: {
        ...process.env,
        TERM: "xterm-256color",
        FORCE_COLOR: "1",
        PYTHONUNBUFFERED: "1",
        DEBIAN_FRONTEND: "noninteractive",
        NEEDRESTART_MODE: "a",
        UCF_FORCE_CONFFOLD: "1",
        APT_LISTCHANGES_FRONTEND: "none",
        CI: "1",
      },
    });

    activeProcess = proc;
    broadcast("status", { isRunning: true, command, processId: pid });

    proc.stdout?.on("data", (chunk: Buffer) => {
      const raw = chunk.toString();
      detectAndHandlePrompt(raw, proc);
      const lines = raw.split("\n");
      for (let i = 0; i < lines.length; i++) {
        if (i === lines.length - 1 && lines[i] === "") continue;
        appendLog("stdout", lines[i]);
      }
    });

    proc.stderr?.on("data", (chunk: Buffer) => {
      const raw = chunk.toString();
      detectAndHandlePrompt(raw, proc);
      const lines = raw.split("\n");
      for (let i = 0; i < lines.length; i++) {
        if (i === lines.length - 1 && lines[i] === "") continue;
        appendLog("stderr", lines[i]);
      }
    });

    proc.on("close", (code, signal) => {
      appendLog(
        "system",
        `[Process exited with code ${code !== null ? code : "null"}${signal ? ` (signal: ${signal})` : ""}]`
      );
      activeProcess = null;
      activeCommand = null;
      activeProcessId = null;
      broadcast("status", { isRunning: false, command: null, processId: null, exitCode: code });
    });

    proc.on("error", (err) => {
      appendLog("system", `[Process spawn error: ${err.message}]`);
      activeProcess = null;
      activeCommand = null;
      activeProcessId = null;
      broadcast("status", { isRunning: false, command: null, processId: null, error: err.message });
    });

    return { ok: true };
  } catch (err: any) {
    appendLog("system", `[Execution failure: ${err.message}]`);
    activeProcess = null;
    activeCommand = null;
    activeProcessId = null;
    return { ok: false, message: err.message };
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // SSE Stream
  app.get("/api/terminal/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    sseClients.add(res);

    // Send initial snapshot
    res.write(
      `event: init\ndata: ${JSON.stringify({
        isRunning: !!activeProcess,
        command: activeCommand,
        processId: activeProcessId,
        history: logBuffer.slice(-200),
      })}\n\n`
    );

    req.on("close", () => {
      sseClients.delete(res);
    });
  });

  // Run command endpoint
  app.post("/api/terminal/run", (req, res) => {
    const { command, cwd } = req.body;
    if (!command || typeof command !== "string") {
      res.status(400).json({ error: "Missing or invalid command string" });
      return;
    }
    const result = runCommand(command.trim(), cwd || ".");
    if (!result.ok) {
      res.status(409).json({ error: result.message });
      return;
    }
    res.json({ ok: true, command: command.trim() });
  });

  // Send interactive stdin input to running process
  app.post("/api/terminal/input", (req, res) => {
    const { input } = req.body;
    if (!activeProcess || !activeProcess.stdin) {
      res.status(400).json({ error: "No active process accepting input" });
      return;
    }

    try {
      const textToSend = input !== undefined ? String(input) : "";
      activeProcess.stdin.write(textToSend.endsWith("\n") ? textToSend : textToSend + "\n");
      appendLog("command", `[Sent stdin input]: ${textToSend || "<ENTER>"}`);
      res.json({ ok: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Kill running process
  app.post("/api/terminal/kill", (req, res) => {
    if (!activeProcess) {
      res.json({ ok: true, message: "No active process to terminate" });
      return;
    }

    try {
      activeProcess.kill("SIGTERM");
      setTimeout(() => {
        if (activeProcess) {
          activeProcess.kill("SIGKILL");
        }
      }, 1500);
      appendLog("system", "[Sent SIGTERM termination signal to process]");
      res.json({ ok: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Clear terminal logs
  app.post("/api/terminal/clear", (req, res) => {
    logBuffer.length = 0;
    broadcast("clear", {});
    res.json({ ok: true });
  });

  // Force unlock dpkg / apt locks
  app.post("/api/terminal/unlock", (req, res) => {
    try {
      clearDpkgLocks();
      appendLog("system", "[Manual Action: Cleared /var/lib/dpkg/lock-frontend and freed apt locks]");
      res.json({ ok: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get status
  app.get("/api/terminal/status", (req, res) => {
    res.json({
      isRunning: !!activeProcess,
      command: activeCommand,
      processId: activeProcessId,
      bufferLength: logBuffer.length,
    });
  });

  // System Diagnostics
  app.get("/api/system/info", (req, res) => {
    let memInfo = "";
    try {
      memInfo = fs.readFileSync("/proc/meminfo", "utf8");
    } catch {
      memInfo = "Unavailable";
    }

    const hasNewgen = fs.existsSync(path.resolve(process.cwd(), "newgen"));
    const newgenFiles = hasNewgen
      ? fs.readdirSync(path.resolve(process.cwd(), "newgen")).slice(0, 30)
      : [];

    res.json({
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      uptime: process.uptime(),
      cwd: process.cwd(),
      memInfo: memInfo.split("\n").slice(0, 8).join("\n"),
      hasNewgen,
      newgenFiles,
    });
  });

  // Download Entire Project ZIP
  app.get("/api/download/project-zip", (req, res) => {
    try {
      execSync("python3 generate_zip.py", { cwd: process.cwd() });
      const zipPath = path.resolve(process.cwd(), "public", "newgen-terminal-full-project.zip");
      if (fs.existsSync(zipPath)) {
        res.download(zipPath, "newgen-terminal-full-project.zip");
      } else {
        res.status(404).json({ error: "ZIP file not found" });
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Download Info Metadata
  app.get("/api/download/info", (req, res) => {
    try {
      const zipPath = path.resolve(process.cwd(), "public", "newgen-terminal-full-project.zip");
      if (!fs.existsSync(zipPath)) {
        execSync("python3 generate_zip.py", { cwd: process.cwd() });
      }
      const stat = fs.statSync(zipPath);
      res.json({
        filename: "newgen-terminal-full-project.zip",
        sizeBytes: stat.size,
        sizeFormatted: `${(stat.size / 1024).toFixed(1)} KB`,
        lastModified: stat.mtime.toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware / production static
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Live Terminal Server running at http://localhost:${PORT}`);
  });
}

startServer();
