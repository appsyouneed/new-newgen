export interface LogEntry {
  id: string;
  timestamp: string;
  type: "stdout" | "stderr" | "system" | "command";
  text: string;
}

export interface TerminalStatus {
  isRunning: boolean;
  command: string | null;
  processId: string | null;
  bufferLength?: number;
  exitCode?: number | null;
}

export interface SystemInfo {
  nodeVersion: string;
  platform: string;
  arch: string;
  uptime: number;
  cwd: string;
  memInfo: string;
  hasNewgen: boolean;
  newgenFiles: string[];
}
