/**
 * Basic ANSI escape sequence stripper and highlighter for web terminal output
 */
export function stripAnsi(text: string): string {
  return text.replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, "");
}

export function formatLogText(text: string): string {
  return stripAnsi(text);
}
